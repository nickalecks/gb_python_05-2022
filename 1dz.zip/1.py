a=0
b=0
a=input('Enter number ')
b=int(input('Enter second number '))
print (type(a),a)
print(type(b),b)