n=0
n=int(input('Введите число '))
n=int(f'{n}')+int(f'{n}{n}')+int(f'{n}{n}{n}')
print(n)
